package com.example.projeto_tassi;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
