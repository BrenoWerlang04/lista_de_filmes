import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/firebase_service.dart';

class MovieListScreen extends StatelessWidget {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  MovieListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lista de Filmes')),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder(
              stream: FirebaseFirestore.instance.collection('movies').snapshots(),
              builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                return ListView(
                  children: snapshot.data!.docs.map((movie) {
                    return ListTile(
                      leading: Checkbox(
                        value: movie['watched'],
                        onChanged: (value) => FirebaseService.updateWatchedStatus(movie.id, value!),
                      ),
                      title: Text(movie['title']),
                      subtitle: Text(movie['description']),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit),
                            onPressed: () => _editMovieDialog(context, movie),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete),
                            onPressed: () => FirebaseService.deleteMovie(movie.id),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: () => _addMovieDialog(context),
              child: const Text('Adicionar Filme'),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _addMovieDialog(BuildContext context) async {
    titleController.clear();
    descriptionController.clear();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Novo Filme'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: 'Título'),
            ),
            TextField(
              controller: descriptionController,
              decoration: InputDecoration(labelText: 'Descrição'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () async {
              await FirebaseService.addMovie(
                titleController.text,
                descriptionController.text,
              );
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Filme adicionado com sucesso!')));
              Navigator.of(context).pop();
            },
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
  }

  Future<void> _editMovieDialog(BuildContext context, QueryDocumentSnapshot movie) async {
    titleController.text = movie['title'];
    descriptionController.text = movie['description'];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Editar Filme'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: 'Título'),
            ),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(labelText: 'Descrição'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () async {
              await FirebaseService.updateMovie(
                movie.id,
                titleController.text,
                descriptionController.text,
              );
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Filme atualizado com sucesso!')));
              Navigator.of(context).pop();
            },
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
  }
}
