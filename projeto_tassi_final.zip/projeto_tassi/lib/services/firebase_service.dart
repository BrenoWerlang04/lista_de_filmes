import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseService {
  static Future<void> addMovie(String title, String description) async {
    await FirebaseFirestore.instance.collection('movies').add({
      'title': title,
      'description': description,
      'watched': false,
    });
  }

  static Future<void> updateMovie(String id, String title, String description) async {
    await FirebaseFirestore.instance.collection('movies').doc(id).update({
      'title': title,
      'description': description,
    });
  }

  static Future<void> updateWatchedStatus(String id, bool watched) async {
    await FirebaseFirestore.instance.collection('movies').doc(id).update({
      'watched': watched,
    });
  }

  static Future<void> deleteMovie(String id) async {
    await FirebaseFirestore.instance.collection('movies').doc(id).delete();
  }
}
